function varargout = pow10(varargin)
%POW10 (overloaded)

varargout{1} = 10.^varargin{1};
