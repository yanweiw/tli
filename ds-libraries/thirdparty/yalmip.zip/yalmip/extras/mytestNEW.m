function y = mytestNEW(B,X)

y = B - X*X;