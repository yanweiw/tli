function selectsolution(k)

yalmip('selectsolution',k);
