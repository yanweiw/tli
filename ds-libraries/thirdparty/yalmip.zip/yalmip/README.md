YALMIP
======

MATLAB toolbox for optimization modeling

Official download site and Wiki http://users.isy.liu.se/johanl/yalmip/
